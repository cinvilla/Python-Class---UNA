def test_print_simple():
    print ('Este es la prueba de impresion de texto en pantalla')