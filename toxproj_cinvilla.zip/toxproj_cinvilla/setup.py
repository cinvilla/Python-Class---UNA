from setuptools import setup

setup(
    name='setup.py',
    version='',
    packages=[''],
    url='',
    license='',
    author='ANS',
    author_email='',
    description=''
)
